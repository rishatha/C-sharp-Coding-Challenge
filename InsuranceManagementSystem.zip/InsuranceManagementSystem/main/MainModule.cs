﻿using dao;
using entity;
using exception;
using InsuranceManagementSystem.entity;
using System;

namespace main
{
    class MainModule
    {
        static void Main()
        {
            IPolicyService policyService = new InsuranceServiceImpl();
            IClientClaimPaymentService clientService = new ClientClaimPaymentServiceImpl();

            while (true)
            {
                Console.WriteLine("\n--- Insurance Management System ---");
                Console.WriteLine("1. Create Policy");
                Console.WriteLine("2. View All Policies");
                Console.WriteLine("3. Add Client");
                Console.WriteLine("4. View Client by ID");
                Console.WriteLine("5. Add Claim");
                Console.WriteLine("6. View Claims by Client");
                Console.WriteLine("7. Add Payment");
                Console.WriteLine("8. View Payments by Client");
                Console.WriteLine("9. Update Policy");
                Console.WriteLine("10. Delete Policy");
                Console.WriteLine("11. Exit");
                Console.Write("Enter your choice: ");
                int ch = int.Parse(Console.ReadLine());

                try
                {
                    switch (ch)
                    {
                        case 1:
                            Console.Write("Enter Policy Name: ");
                            string pname = Console.ReadLine();
                            Console.Write("Enter Coverage Amount: ");
                            decimal coverage = decimal.Parse(Console.ReadLine());
                            Console.Write("Enter Premium: ");
                            decimal premium = decimal.Parse(Console.ReadLine());
                            Console.Write("Enter Term (in years): ");
                            int term = int.Parse(Console.ReadLine());

                            Policy newPolicy = new Policy(0, pname, coverage, premium, term);
                            bool policyCreated = policyService.CreatePolicy(newPolicy);
                            Console.WriteLine(policyCreated ? "Policy created." : "Failed to create policy.");
                            break;

                        case 2:
                            var allPolicies = policyService.GetAllPolicies();
                            foreach (var policy in allPolicies)
                                Console.WriteLine(policy);
                            break;

                        case 3:
                            Console.Write("Enter Client Name: ");
                            string cname = Console.ReadLine();
                            Console.Write("Enter Contact Info: ");
                            string contact = Console.ReadLine();
                            Console.Write("Enter Policy ID: ");
                            int pid = int.Parse(Console.ReadLine());

                            Policy clientPolicy = policyService.GetPolicy(pid);
                            Client client = new Client(0, cname, contact, clientPolicy);
                            bool clientAdded = clientService.AddClient(client);
                            Console.WriteLine(clientAdded ? "Client added." : "Failed to add client.");
                            break;

                        case 4:
                            Console.Write("Enter Client ID: ");
                            int cid = int.Parse(Console.ReadLine());
                            Client c = clientService.GetClientById(cid);
                            Console.WriteLine(c);
                            break;

                        case 5:
                            Console.Write("Enter Claim Number: ");
                            string clNum = Console.ReadLine();
                            Console.Write("Enter Claim Amount: ");
                            decimal clAmt = decimal.Parse(Console.ReadLine());
                            Console.Write("Enter Status: ");
                            string clStat = Console.ReadLine();
                            Console.Write("Enter Policy ID: ");
                            int polId = int.Parse(Console.ReadLine());
                            Console.Write("Enter Client ID: ");
                            int clId = int.Parse(Console.ReadLine());

                            Policy pol = policyService.GetPolicy(polId);
                            Client cli = clientService.GetClientById(clId);
                            Claim claim = new Claim(0, clNum, DateTime.Now, clAmt, clStat, pol, cli);
                            bool claimAdded = clientService.AddClaim(claim);
                            Console.WriteLine(claimAdded ? "Claim added." : "Failed to add claim.");
                            break;

                        case 6:
                            Console.Write("Enter Client ID: ");
                            int ccid = int.Parse(Console.ReadLine());
                            var claims = clientService.GetClaimsByClientId(ccid);
                            foreach (var cl in claims)
                                Console.WriteLine(cl);
                            break;

                        case 7:
                            Console.Write("Enter Payment Amount: ");
                            decimal payAmt = decimal.Parse(Console.ReadLine());
                            Console.Write("Enter Client ID: ");
                            int pcid = int.Parse(Console.ReadLine());
                            Client pc = clientService.GetClientById(pcid);
                            Payment payment = new Payment(0, DateTime.Now, payAmt, pc);
                            bool payAdded = clientService.AddPayment(payment);
                            Console.WriteLine(payAdded ? "Payment added." : "Failed to add payment.");
                            break;

                        case 8:
                            Console.Write("Enter Client ID: ");
                            int vpcid = int.Parse(Console.ReadLine());
                            var payments = clientService.GetPaymentsByClientId(vpcid);
                            foreach (var p in payments)
                                Console.WriteLine(p);
                            break;

                        case 9: // Update Policy
                            Console.Write("Enter Policy ID to Update: ");
                            int upid = int.Parse(Console.ReadLine());
                            Policy existingPolicy = policyService.GetPolicy(upid);
                            Console.Write("Enter New Policy Name: ");
                            string npname = Console.ReadLine();
                            Console.Write("Enter New Coverage Amount: ");
                            decimal ncoverage = decimal.Parse(Console.ReadLine());
                            Console.Write("Enter New Premium: ");
                            decimal npremium = decimal.Parse(Console.ReadLine());
                            Console.Write("Enter New Term (years): ");
                            int nterm = int.Parse(Console.ReadLine());

                            existingPolicy.PolicyName = npname;
                            existingPolicy.CoverageAmount = ncoverage;
                            existingPolicy.Premium = npremium;
                            existingPolicy.Term = nterm;

                            bool updated = policyService.UpdatePolicy(existingPolicy);
                            Console.WriteLine(updated ? "Policy updated." : "Update failed.");
                            break;

                        case 10: // Delete Policy
                            Console.Write("Enter Policy ID to Delete: ");
                            int delId = int.Parse(Console.ReadLine());
                            bool deleted = policyService.DeletePolicy(delId);
                            Console.WriteLine(deleted ? "Policy deleted." : "Delete failed.");
                            break;

                        case 11:
                            Console.WriteLine("Exiting...");
                            return;

                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                }
                catch (PolicyNotFoundException ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Unexpected error: " + ex.Message);
                }
            }
        }
    }
}
