﻿using entity;
using InsuranceManagementSystem.entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using util;

namespace dao
{
    public class ClientClaimPaymentServiceImpl : IClientClaimPaymentService
    {
        SqlConnection connection;

        public ClientClaimPaymentServiceImpl()
        {
            connection = DBConnUtil.GetConnection();
        }

        public bool AddClient(Client client)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Client (ClientName, ContactInfo, PolicyId) VALUES (@name, @contact, @policyId)", connection);
            cmd.Parameters.AddWithValue("@name", client.ClientName);
            cmd.Parameters.AddWithValue("@contact", client.ContactInfo);
            cmd.Parameters.AddWithValue("@policyId", client.Policy.PolicyId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public Client GetClientById(int clientId)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM Client c JOIN Policy p ON c.PolicyId = p.PolicyId WHERE c.ClientId = @id", connection);
            cmd.Parameters.AddWithValue("@id", clientId);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                Policy policy = new Policy(
                    (int)reader["PolicyId"],
                    reader["PolicyName"].ToString(),
                    (decimal)reader["CoverageAmount"],
                    (decimal)reader["Premium"],
                    (int)reader["Term"]
                );

                Client client = new Client(
                    (int)reader["ClientId"],
                    reader["ClientName"].ToString(),
                    reader["ContactInfo"].ToString(),
                    policy
                );
                reader.Close();
                return client;
            }
            reader.Close();
            return null;
        }

        public List<Client> GetAllClients()
        {
            List<Client> clients = new List<Client>();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Client c JOIN Policy p ON c.PolicyId = p.PolicyId", connection);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Policy policy = new Policy(
                    (int)reader["PolicyId"],
                    reader["PolicyName"].ToString(),
                    (decimal)reader["CoverageAmount"],
                    (decimal)reader["Premium"],
                    (int)reader["Term"]
                );

                clients.Add(new Client(
                    (int)reader["ClientId"],
                    reader["ClientName"].ToString(),
                    reader["ContactInfo"].ToString(),
                    policy
                ));
            }
            reader.Close();
            return clients;
        }

        public bool AddClaim(Claim claim)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Claim (ClaimNumber, DateFiled, ClaimAmount, Status, PolicyId, ClientId) VALUES (@num, @date, @amt, @status, @policyId, @clientId)", connection);
            cmd.Parameters.AddWithValue("@num", claim.ClaimNumber);
            cmd.Parameters.AddWithValue("@date", claim.DateFiled);
            cmd.Parameters.AddWithValue("@amt", claim.ClaimAmount);
            cmd.Parameters.AddWithValue("@status", claim.Status);
            cmd.Parameters.AddWithValue("@policyId", claim.Policy.PolicyId);
            cmd.Parameters.AddWithValue("@clientId", claim.Client.ClientId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public List<Claim> GetClaimsByClientId(int clientId)
        {
            List<Claim> claims = new List<Claim>();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Claim c JOIN Policy p ON c.PolicyId = p.PolicyId WHERE c.ClientId = @clientId", connection);
            cmd.Parameters.AddWithValue("@clientId", clientId);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Policy policy = new Policy(
                    (int)reader["PolicyId"],
                    reader["PolicyName"].ToString(),
                    (decimal)reader["CoverageAmount"],
                    (decimal)reader["Premium"],
                    (int)reader["Term"]
                );

                Client client = new Client(clientId, "", "", policy); 

                claims.Add(new Claim(
                    (int)reader["ClaimId"],
                    reader["ClaimNumber"].ToString(),
                    (DateTime)reader["DateFiled"],
                    (decimal)reader["ClaimAmount"],
                    reader["Status"].ToString(),
                    policy,
                    client
                ));
            }
            reader.Close();
            return claims;
        }

        public bool AddPayment(Payment payment)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Payment (PaymentDate, PaymentAmount, ClientId) VALUES (@date, @amt, @clientId)", connection);
            cmd.Parameters.AddWithValue("@date", payment.PaymentDate);
            cmd.Parameters.AddWithValue("@amt", payment.PaymentAmount);
            cmd.Parameters.AddWithValue("@clientId", payment.Client.ClientId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public List<Payment> GetPaymentsByClientId(int clientId)
        {
            List<Payment> payments = new List<Payment>();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Payment WHERE ClientId = @clientId", connection);
            cmd.Parameters.AddWithValue("@clientId", clientId);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                payments.Add(new Payment(
                    (int)reader["PaymentId"],
                    (DateTime)reader["PaymentDate"],
                    (decimal)reader["PaymentAmount"],
                    new Client(clientId, "", "", null)
                ));
            }
            reader.Close();
            return payments;
        }
    }
}
