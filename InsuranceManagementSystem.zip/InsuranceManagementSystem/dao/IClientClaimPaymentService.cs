﻿using InsuranceManagementSystem.entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dao
{
    public interface IClientClaimPaymentService
    {
        bool AddClient(Client client);
        Client GetClientById(int clientId);
        List<Client> GetAllClients();

        bool AddClaim(Claim claim);
        List<Claim> GetClaimsByClientId(int clientId);

        bool AddPayment(Payment payment);
        List<Payment> GetPaymentsByClientId(int clientId);
    }
}
