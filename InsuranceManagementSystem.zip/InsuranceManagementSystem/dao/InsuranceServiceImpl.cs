﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using entity;
using exception;
using util;

namespace dao
{
    public class InsuranceServiceImpl : IPolicyService
    {
        private SqlConnection connection;

        public InsuranceServiceImpl()
        {
            connection = DBConnUtil.GetConnection();
        }

        public bool CreatePolicy(Policy policy)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Policy (PolicyName, CoverageAmount, Premium, Term) VALUES (@name, @coverage, @premium, @term)", connection);
            cmd.Parameters.AddWithValue("@name", policy.PolicyName);
            cmd.Parameters.AddWithValue("@coverage", policy.CoverageAmount);
            cmd.Parameters.AddWithValue("@premium", policy.Premium);
            cmd.Parameters.AddWithValue("@term", policy.Term);
            return cmd.ExecuteNonQuery() > 0;
        }

        public Policy GetPolicy(int policyId)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM Policy WHERE PolicyId = @id", connection);
            cmd.Parameters.AddWithValue("@id", policyId);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                Policy p = new Policy(
                    (int)reader["PolicyId"],
                    reader["PolicyName"].ToString(),
                    (decimal)reader["CoverageAmount"],
                    (decimal)reader["Premium"],
                    (int)reader["Term"]
                );
                reader.Close();
                return p;
            }
            reader.Close();
            throw new PolicyNotFoundException("Policy not found!");
        }

        public List<Policy> GetAllPolicies()
        {
            List<Policy> list = new List<Policy>();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Policy", connection);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                list.Add(new Policy(
                    (int)reader["PolicyId"],
                    reader["PolicyName"].ToString(),
                    (decimal)reader["CoverageAmount"],
                    (decimal)reader["Premium"],
                    (int)reader["Term"]
                ));
            }
            reader.Close();
            return list;
        }

        public bool UpdatePolicy(Policy policy)
        {
            SqlCommand cmd = new SqlCommand("UPDATE Policy SET PolicyName=@name, CoverageAmount=@coverage, Premium=@premium, Term=@term WHERE PolicyId=@id", connection);
            cmd.Parameters.AddWithValue("@name", policy.PolicyName);
            cmd.Parameters.AddWithValue("@coverage", policy.CoverageAmount);
            cmd.Parameters.AddWithValue("@premium", policy.Premium);
            cmd.Parameters.AddWithValue("@term", policy.Term);
            cmd.Parameters.AddWithValue("@id", policy.PolicyId);
            return cmd.ExecuteNonQuery() > 0;
        }

        public bool DeletePolicy(int policyId)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM Policy WHERE PolicyId = @id", connection);
            cmd.Parameters.AddWithValue("@id", policyId);
            return cmd.ExecuteNonQuery() > 0;
        }
    }
}
