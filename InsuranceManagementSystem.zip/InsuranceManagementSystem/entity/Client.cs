﻿using entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystem.entity
{
    public class Client
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string ContactInfo { get; set; }
        public Policy Policy { get; set; }

        public Client() { }

        public Client(int id, string name, string contact, Policy policy)
        {
            ClientId = id;
            ClientName = name;
            ContactInfo = contact;
            Policy = policy;
        }

        public override string ToString()
        {
            return $"Client ID: {ClientId}, Name: {ClientName}, Contact: {ContactInfo}, Policy: [{Policy?.ToString()}]";
        }
    }
}
