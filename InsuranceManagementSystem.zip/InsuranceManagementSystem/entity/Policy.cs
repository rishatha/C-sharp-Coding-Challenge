﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entity
{
    public class Policy
    {
        public int PolicyId { get; set; }
        public string PolicyName { get; set; }
        public decimal CoverageAmount { get; set; }
        public decimal Premium { get; set; }
        public int Term { get; set; }

        public Policy() { }

        public Policy(int id, string name, decimal coverage, decimal premium, int term)
        {
            PolicyId = id;
            PolicyName = name;
            CoverageAmount = coverage;
            Premium = premium;
            Term = term;
        }

        public override string ToString()
        {
            return $"{PolicyId}: {PolicyName}, Coverage: {CoverageAmount}, Premium: {Premium}, Term: {Term}";
        }
    }
}
