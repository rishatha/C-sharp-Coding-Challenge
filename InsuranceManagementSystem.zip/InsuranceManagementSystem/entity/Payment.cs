﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystem.entity
{
    public class Payment
    {
        public int PaymentId { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal PaymentAmount { get; set; }
        public Client Client { get; set; }

        public Payment() { }

        public Payment(int id, DateTime date, decimal amount, Client client)
        {
            PaymentId = id;
            PaymentDate = date;
            PaymentAmount = amount;
            Client = client;
        }

        public override string ToString()
        {
            return $"Payment ID: {PaymentId}, Date: {PaymentDate.ToShortDateString()}, Amount: {PaymentAmount}, Client: [{Client?.ClientName}]";
        }
    }
}
