﻿using entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsuranceManagementSystem.entity
{
    public class Claim
    {
        public int ClaimId { get; set; }
        public string ClaimNumber { get; set; }
        public DateTime DateFiled { get; set; }
        public decimal ClaimAmount { get; set; }
        public string Status { get; set; }
        public Policy Policy { get; set; }
        public Client Client { get; set; }

        public Claim() { }

        public Claim(int id, string number, DateTime date, decimal amount, string status, Policy policy, Client client)
        {
            ClaimId = id;
            ClaimNumber = number;
            DateFiled = date;
            ClaimAmount = amount;
            Status = status;
            Policy = policy;
            Client = client;
        }

        public override string ToString()
        {
            return $"Claim #{ClaimNumber} | Date: {DateFiled.ToShortDateString()}, Amount: {ClaimAmount}, Status: {Status}, " +
                   $"Client: [{Client?.ClientName}], Policy: [{Policy?.PolicyName}]";
        }
    }
}
